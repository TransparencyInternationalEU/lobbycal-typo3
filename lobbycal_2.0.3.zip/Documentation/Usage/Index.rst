﻿.. include:: Images.txt

.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. ==================================================
.. DEFINE SOME TEXTROLES
.. --------------------------------------------------
.. role::   underline
.. role::   typoscript(code)
.. role::   ts(typoscript)
   :class:  typoscript
.. role::   php(code)


Usage
-----

1. Install the extension with the Extension Manager.

2. Configure your settings with TYPOSCRIPT constants in the TYPO3 backend, all parameters are listed in the Constant Editor.

3. Include the LobbyCal TYPOSCRIPT Extension in your TYPOSCRIPT Template ("Includes")

4. Choose if you want to include jQuery from the extension (include_jquery = 1).

5. Place plugin on the page, where you want to list the meetings.
